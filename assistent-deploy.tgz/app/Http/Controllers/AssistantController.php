<?php
namespace App\Http\Controllers;
use App\Models\{Assistant,KnowledgeBase};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
class AssistantController extends Controller {
    public function index(Request $r) { return Assistant::where('user_id',$r->user()->id)->with('knowledgeBases:id,name,status')->when($r->q,fn($q)=>$q->where('name','like','%'.mb_substr($r->q,0,100).'%'))->latest()->paginate(30); }
    public function store(Request $r) { return response()->json($this->save($r,new Assistant(['user_id'=>$r->user()->id])),201); }
    public function update(Request $r,Assistant $assistant) { Gate::authorize('manage',$assistant); return $this->save($r,$assistant); }
    private function save(Request $r,Assistant $assistant): Assistant {
        $data=$r->validate(['name'=>'required|string|max:100','description'=>'nullable|string|max:2000','goal'=>'nullable|string|max:3000','instructions'=>'nullable|string|max:8000','active'=>'boolean','settings'=>'nullable|array','settings.style'=>'nullable|string|max:300','settings.greeting'=>'nullable|string|max:1000','settings.no_knowledge'=>'nullable|string|max:1000','settings.context_messages'=>'nullable|integer|min:2|max:30','settings.max_length'=>'nullable|integer|min:200|max:3900','knowledge_base_ids'=>'array','knowledge_base_ids.*'=>'integer']);
        $ids=$data['knowledge_base_ids']??[];
        abort_if(KnowledgeBase::where('user_id',$r->user()->id)->whereIn('id',$ids)->count()!==count(array_unique($ids)),403);
        unset($data['knowledge_base_ids']);
        $data['settings']=array_intersect_key($data['settings']??[],array_flip(['style','greeting','no_knowledge','context_messages','max_length']))+['strict_knowledge'=>true];
        $assistant->fill($data)->save(); $assistant->knowledgeBases()->sync($ids); return $assistant->load('knowledgeBases:id,name,status');
    }
    public function destroy(Assistant $assistant) { Gate::authorize('manage',$assistant); abort_if(\App\Models\Integration::where('assistant_id',$assistant->id)->where('status','connected')->exists(),422,'Сначала отключите каналы ассистента.'); $assistant->delete(); return ['ok'=>true]; }
}
