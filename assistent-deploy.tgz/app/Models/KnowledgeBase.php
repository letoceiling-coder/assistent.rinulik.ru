<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class KnowledgeBase extends Model {
    use \Illuminate\Database\Eloquent\SoftDeletes;
    protected $guarded = ['id'];
    protected function casts(): array { return ['indexed_at'=>'datetime']; }
    public function documents() { return $this->hasMany(KnowledgeDocument::class); }
}
