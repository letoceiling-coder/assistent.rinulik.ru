<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Assistant extends Model {
    use \Illuminate\Database\Eloquent\SoftDeletes;
    protected $guarded = ['id'];
    protected function casts(): array { return ['settings'=>'array','active'=>'boolean']; }
    public function knowledgeBases() { return $this->belongsToMany(KnowledgeBase::class); }
}
