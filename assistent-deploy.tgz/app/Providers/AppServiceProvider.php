<?php
namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\{Gate,RateLimiter,Queue,Cache};
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
class AppServiceProvider extends ServiceProvider {
    public function register(): void {}
    public function boot(): void {
        Gate::define('admin',fn($u)=>$u->role==='super_admin' && !$u->blocked);
        foreach ([\App\Models\Assistant::class,\App\Models\KnowledgeBase::class,\App\Models\Conversation::class,\App\Models\Lead::class,\App\Models\Integration::class] as $model) Gate::policy($model,\App\Policies\OwnedPolicy::class);
        RateLimiter::for('auth',fn(Request $r)=>[Limit::perMinute(8)->by($r->ip()),Limit::perMinute(5)->by(mb_strtolower((string)$r->email).$r->ip())]);
        Queue::looping(fn()=>Cache::put('worker-heartbeat',now()->toIso8601String(),120));
    }
}
